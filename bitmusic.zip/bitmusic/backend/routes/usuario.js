
'use strict'
var app = require ('express');
var UsuarioController = 
require('../controllers/usuario')
var api = app.Router();
api.get('/prueba_usuario', UsuarioController.prueba_usuario);
api.post('/usuario', UsuarioController.crearUsuario);
api.put('/usuario/:id', UsuarioController.actualizarUsuario);
api.delete('/usuario/:id', UsuarioController.eliminarUsuario);
module.exports = api; 