'use strict'
var Usuario = require('../models/usuario')

function prueba_usuario(req,res){
    res.status(200).send({
        message : "controlador usuario"
        +" esta funcionando"
    })
}

function crearUsuario(req,res){
    var usuario = new Usuario();
    var params = req.body;

    usuario.nombre = params.nombre;
    usuario.edad = params.edad;
    usuario.correo = params.correo;
    usuario.password = params.password;
    usuario.imagen = params.imagen;
    usuario.role = params.role;

    usuario.save()
    .then((usuarioGuardado)=>{
        if(!usuarioGuardado){
            res.status(404).send({message:'No se ha registrado el usuario'});
        }else{
            res.status(200).send({usuario:usuarioGuardado});
        }
    }).catch(error =>{
        res.status(500).send({message:'Error al guardar el usuario'});
    })
}



function actualizarUsuario(req,res){
    var idUsuario = req.params.id;
    var nuevosDatos = req.body;
    
    Usuario.findByIdAndUpdate(idUsuario,nuevosDatos).exec()
    .then((usuarioActualizado)=>{
        if (!usuarioActualizado) {
            res.status(404).send({ message: "El usuario no ha sido actualizado" });
        } else {
            res.status(200).send({ empleado: usuarioActualizado });
        }
    }).catch(error =>{
        res.status(500).send({ message: "Error al actualizar el usuario" });
    })
}

function eliminarUsuario(req,res){
    var idUsuario = req.params.id;
    
    Usuario.findByIdAndRemove(idUsuario).exec()
    .then((usuarioEliminado)=>{
        if (!usuarioEliminado) {
            res.status(404).send({ message: "El usuario no ha sido eliminado" });
        } else {
            res.status(200).send({ usuario:usuarioEliminado, message: "El usuario ha sido eliminado"  });
           
        }
    }).catch(error =>{
        res.status(500).send({ message: "Error al eliminar el usuario" });
    })
    
}

module.exports = {
    prueba_usuario,
    crearUsuario,
    actualizarUsuario,
    eliminarUsuario
    
}
 

